import math
import unittest

from cachetools import TTLCache

from . import CacheTestMixin


class Timer:
    def __init__(self, auto=False):
        self.auto = auto
        self.time = 0

    def __call__(self):
        if self.auto:
            self.time += 1
        return self.time

    def tick(self):
        self.time += 1


class TTLTestCache(TTLCache):
    def __init__(self, maxsize, ttl=math.inf, **kwargs):
        TTLCache.__init__(self, maxsize, ttl=ttl, timer=Timer(), **kwargs)


class TTLCacheTest(unittest.TestCase, CacheTestMixin):
    Cache = TTLTestCache

    def test_ttl(self):
        cache = TTLCache[int, int, int](maxsize=2, ttl=2, timer=Timer())
        self.assertEqual(0, cache.timer())
        self.assertEqual(2, cache.ttl)

        cache[1] = 1
        self.assertEqual(1, cache[1])
        self.assertEqual(1, len(cache))
        self.assertEqual({1}, set(cache))

        cache.timer.tick()
        self.assertEqual(1, cache[1])
        self.assertEqual(1, len(cache))
        self.assertEqual({1}, set(cache))

        cache[2] = 2
        self.assertEqual(1, cache[1])
        self.assertEqual(2, cache[2])
        self.assertEqual(2, len(cache))
        self.assertEqual({1, 2}, set(cache))

        cache.timer.tick()
        self.assertNotIn(1, cache)
        self.assertEqual(2, cache[2])
        self.assertEqual(1, len(cache))
        self.assertEqual({2}, set(cache))

        cache[3] = 3
        self.assertNotIn(1, cache)
        self.assertEqual(2, cache[2])
        self.assertEqual(3, cache[3])
        self.assertEqual(2, len(cache))
        self.assertEqual({2, 3}, set(cache))

        cache.timer.tick()
        self.assertNotIn(1, cache)
        self.assertNotIn(2, cache)
        self.assertEqual(3, cache[3])
        self.assertEqual(1, len(cache))
        self.assertEqual({3}, set(cache))

        cache.timer.tick()
        self.assertNotIn(1, cache)
        self.assertNotIn(2, cache)
        self.assertNotIn(3, cache)

        with self.assertRaises(KeyError):
            del cache[1]
        with self.assertRaises(KeyError):
            cache.pop(2)
        with self.assertRaises(KeyError):
            del cache[3]

        self.assertEqual(0, len(cache))
        self.assertEqual(set(), set(cache))

    def test_ttl_timer(self):
        cache = TTLCache[int, int, int](maxsize=2, ttl=2, timer=Timer())
        self.assertEqual(cache.timer.time, 0)
        self.assertFalse(cache.timer.auto)

        cache[1] = 1
        cache.timer.tick()
        self.assertEqual(cache.timer.time, 1)
        self.assertEqual(1, cache[1])

        cache.timer.tick()
        self.assertEqual(cache.timer.time, 2)
        self.assertNotIn(1, cache)

    def test_ttl_lru(self):
        cache = TTLCache[int, int, int](maxsize=2, ttl=1, timer=Timer())

        cache[1] = 1
        cache[2] = 2
        cache[3] = 3

        self.assertEqual(len(cache), 2)
        self.assertNotIn(1, cache)
        self.assertEqual(cache[2], 2)
        self.assertEqual(cache[3], 3)

        cache[2]
        cache[4] = 4
        self.assertEqual(len(cache), 2)
        self.assertNotIn(1, cache)
        self.assertEqual(cache[2], 2)
        self.assertNotIn(3, cache)
        self.assertEqual(cache[4], 4)

        cache[5] = 5
        self.assertEqual(len(cache), 2)
        self.assertNotIn(1, cache)
        self.assertNotIn(2, cache)
        self.assertNotIn(3, cache)
        self.assertEqual(cache[4], 4)
        self.assertEqual(cache[5], 5)

    def test_ttl_expire(self):
        cache = TTLCache[int, int, int](maxsize=3, ttl=3, timer=Timer())
        with cache.timer as time:
            self.assertEqual(time, cache.timer())
        self.assertEqual(3, cache.ttl)

        cache[1] = 1
        cache.timer.tick()
        cache[2] = 2
        cache.timer.tick()
        cache[3] = 3
        self.assertEqual(2, cache.timer())

        self.assertEqual({1, 2, 3}, set(cache))
        self.assertEqual(3, len(cache))
        self.assertEqual(1, cache[1])
        self.assertEqual(2, cache[2])
        self.assertEqual(3, cache[3])

        items = cache.expire()
        self.assertEqual(set(), set(items))
        self.assertEqual({1, 2, 3}, set(cache))
        self.assertEqual(3, len(cache))
        self.assertEqual(1, cache[1])
        self.assertEqual(2, cache[2])
        self.assertEqual(3, cache[3])

        items = cache.expire(3)
        self.assertEqual({(1, 1)}, set(items))
        self.assertEqual({2, 3}, set(cache))
        self.assertEqual(2, len(cache))
        self.assertNotIn(1, cache)
        self.assertEqual(2, cache[2])
        self.assertEqual(3, cache[3])

        items = cache.expire(4)
        self.assertEqual({(2, 2)}, set(items))
        self.assertEqual({3}, set(cache))
        self.assertEqual(1, len(cache))
        self.assertNotIn(1, cache)
        self.assertNotIn(2, cache)
        self.assertEqual(3, cache[3])

        items = cache.expire(5)
        self.assertEqual({(3, 3)}, set(items))
        self.assertEqual(set(), set(cache))
        self.assertEqual(0, len(cache))
        self.assertNotIn(1, cache)
        self.assertNotIn(2, cache)
        self.assertNotIn(3, cache)

    def test_ttl_iter_expired(self):
        cache = TTLCache[int, int, int](maxsize=2, ttl=2, timer=Timer())
        cache[1] = 1
        cache.timer.tick()
        cache[2] = 2
        cache.timer.tick()
        # a bare for loop skips expired items without removing them
        self.assertEqual([2], [key for key in cache])
        self.assertEqual({(1, 1)}, set(cache.expire()))
        self.assertEqual([2], [key for key in cache])

    def test_ttl_atomic(self):
        cache = TTLCache[int, int | None, int](maxsize=1, ttl=2, timer=Timer(auto=True))
        cache[1] = 1
        self.assertEqual(1, cache[1])
        cache[1] = 1
        self.assertEqual(1, cache.get(1))
        cache[1] = 1
        self.assertEqual(1, cache.pop(1))
        cache[1] = 1
        self.assertEqual(1, cache.setdefault(1))  # implicit default=None
        cache[1] = 1
        cache.clear()
        self.assertEqual(0, len(cache))

    def test_ttl_tuple_key(self):
        cache = TTLCache[tuple[int, ...], int, int](maxsize=1, ttl=1, timer=Timer())
        self.assertEqual(1, cache.ttl)

        cache[(1, 2, 3)] = 42
        self.assertEqual(42, cache[(1, 2, 3)])
        cache.timer.tick()
        with self.assertRaises(KeyError):
            cache[(1, 2, 3)]
        self.assertNotIn((1, 2, 3), cache)

    def test_ttl_datetime(self):
        from datetime import datetime, timedelta

        cache = TTLCache[int, int, datetime](
            maxsize=1, ttl=timedelta(days=1), timer=datetime.now
        )

        cache[1] = 1
        self.assertEqual(1, len(cache))
        items = cache.expire(datetime.now())
        self.assertEqual([], list(items))
        self.assertEqual(1, len(cache))
        items = cache.expire(datetime.now() + timedelta(days=1))
        self.assertEqual([(1, 1)], list(items))
        self.assertEqual(0, len(cache))

    def test_ttl_datetime_overflow(self):
        from datetime import datetime, timedelta

        cache = TTLCache[str, int, datetime](
            maxsize=1, ttl=timedelta(days=1), timer=lambda: datetime.max
        )

        with self.assertRaises(OverflowError):
            cache["overflow"] = 1

        self.assertNotIn("overflow", cache)
        self.assertEqual(0, len(cache))
        self.assertEqual(0, cache.currsize)
        self.assertEqual([], list(cache))
        self.assertEqual([], cache.expire())

    def test_ttl_clear(self):
        cache = TTLCache[int, int, int](maxsize=2, ttl=2, timer=Timer())

        cache[1] = 1
        cache[2] = 2
        cache.clear()

        self.assertEqual(0, len(cache))
        self.assertEqual(0, cache.currsize)

        # verify LRU eviction order is reset after clear
        cache[3] = 3
        cache[4] = 4
        cache[3]  # access 3 to make it most recently used
        cache[5] = 5  # should evict 4 (least recently used)

        self.assertEqual(2, len(cache))
        self.assertIn(3, cache)
        self.assertIn(5, cache)
        self.assertNotIn(4, cache)

        # verify TTL expiry still works after clear
        cache[42] = 42
        cache.timer.tick()
        cache.timer.tick()
        cache.timer.tick()  # past TTL
        self.assertNotIn(42, cache)

    def test_ttl_default_timer_stubs(self):
        # type stubs must infer key and value types with the default timer
        cache: TTLCache[str, int] = TTLCache(maxsize=2, ttl=math.inf)

        cache["a"] = 1
        self.assertEqual(1, cache["a"])
        self.assertEqual(1, len(cache))
        self.assertIn("a", cache)

        sized: TTLCache[str, str] = TTLCache(maxsize=10, ttl=math.inf, getsizeof=len)

        sized["abc"] = "abc"
        self.assertEqual("abc", sized["abc"])
        self.assertEqual(3, sized.currsize)

    def test_ttl_copy(self):
        import copy

        source = TTLCache[int, int, int](maxsize=3, ttl=2, timer=Timer())
        source[1] = 1
        source[2] = 2
        source.timer.tick()
        source[3] = 3
        self.assertEqual(1, source[1])  # least recently used is now 2

        cache = copy.copy(source)
        self.assertEqual([1, 2, 3], list(cache))

        # the copy evicts as its source would, on its own
        cache[4] = 4
        self.assertEqual([1, 3, 4], list(cache))
        self.assertEqual([1, 2, 3], list(source))

        # the timer is shared, but not the caches' use of it
        self.assertIsNot(source.timer, cache.timer)
        with source.timer:
            cache.timer.tick()
            self.assertEqual(1, source.timer())
            self.assertEqual(2, cache.timer())
        self.assertEqual(2, source.timer())

        # items expire in the copy as in its source
        self.assertEqual([3, 4], list(cache))
        self.assertEqual([3], list(source))

    def test_ttl_deepcopy_timer(self):
        import copy

        class DeepCopyTimer(Timer):
            def __deepcopy__(self, memo):
                return copy.copy(self)

        source = TTLCache[int, int, int](maxsize=2, ttl=1, timer=DeepCopyTimer())
        source[1] = 1

        # a timer may define __deepcopy__ itself
        cache = copy.deepcopy(source)
        self.assertEqual([1], list(cache))

        # the copy has a timer of its own
        cache.timer.tick()
        self.assertEqual([], list(cache))
        self.assertEqual([1], list(source))

    def test_ttl_iter_modify(self):
        cache = TTLCache[int, int, int](maxsize=6, ttl=2, timer=Timer())
        cache.update({1: 1, 2: 2, 3: 3})

        # items inserted while iterating are not visited
        keys = []
        for key in cache:
            keys.append(key)
            cache[key + 10] = key
        self.assertEqual([1, 2, 3], keys)
        self.assertEqual([1, 2, 3, 11, 12, 13], list(cache))

        # items removed while iterating are skipped
        keys = []
        for key in cache:
            keys.append(key)
            cache.clear()
        self.assertEqual([1], keys)
        self.assertEqual([], list(cache))
