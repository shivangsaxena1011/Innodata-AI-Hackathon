from decimal import Decimal
import pytest

from shopcart.cart import Cart
from shopcart.catalog import Catalog, Product
from shopcart.pricing import (
    DiscountCoupon,
    PricingError,
    PricingPolicy,
    Totals,
    compute_totals,
)


def _make_catalog() -> Catalog:
    cat = Catalog()
    cat.add(Product("BOOK-1", "Python Tricks", Decimal("24.50"), "books"))
    cat.add(Product("BOOK-2", "Fluent Patterns", Decimal("39.00"), "books"))
    cat.add(Product("FOOD-1", "Coffee Beans", Decimal("12.00"), "grocery"))
    cat.add(Product("TECH-1", "USB-C Cable", Decimal("9.99"), "electronics"))
    return cat


def test_ac1_min_subtotal_below_threshold_raises_pricing_error():
    catalog = _make_catalog()
    cart = Cart(catalog)
    cart.add_item("BOOK-1", 1)  # subtotal = 24.50

    coupon = DiscountCoupon("SAVE10", fixed_amount=Decimal("5.00"), min_subtotal=Decimal("50.00"))

    expected_msg = "cart subtotal 24.50 does not meet coupon minimum 50.00"
    with pytest.raises(PricingError, match=expected_msg):
        compute_totals(cart, coupon=coupon)


def test_ac1_min_subtotal_exact_match_succeeds():
    catalog = _make_catalog()
    cart = Cart(catalog)
    cart.add_item("BOOK-1", 2)  # subtotal = 49.00
    cart.add_item("FOOD-1", 1)  # subtotal = 61.00

    coupon = DiscountCoupon("MIN61", fixed_amount=Decimal("10.00"), min_subtotal=Decimal("61.00"))
    totals = compute_totals(cart, coupon=coupon)
    assert totals.discount == Decimal("10.00")
    assert totals.subtotal == Decimal("61.00")


def test_ac2_valid_percentage_coupon():
    catalog = _make_catalog()
    cart = Cart(catalog)
    cart.add_item("BOOK-2", 2)  # subtotal = 78.00

    policy = PricingPolicy(default_tax_rate=Decimal("10"), flat_shipping=Decimal("5.99"), free_shipping_threshold=Decimal("100.00"))
    coupon = DiscountCoupon("PERCENT15", discount_percent=Decimal("15"))

    # subtotal = 78.00
    # raw discount = percent_of(78.00, 15) = 11.70
    # discount = 11.70
    # discounted_line_base = 78.00 * (1 - 11.70 / 78.00) = 66.30
    # tax = percent_of(66.30, 10) = 6.63
    # shipping = 5.99 (78.00 < 100.00)
    # total = 78.00 - 11.70 + 6.63 + 5.99 = 78.92
    totals = compute_totals(cart, policy, coupon=coupon)
    assert totals.subtotal == Decimal("78.00")
    assert totals.discount == Decimal("11.70")
    assert totals.tax == Decimal("6.63")
    assert totals.shipping == Decimal("5.99")
    assert totals.total == Decimal("78.92")


def test_ac3_clamped_discount_exceeding_subtotal():
    catalog = _make_catalog()
    cart = Cart(catalog)
    cart.add_item("FOOD-1", 1)  # subtotal = 12.00

    policy = PricingPolicy(flat_shipping=Decimal("5.99"), free_shipping_threshold=Decimal("50.00"))
    coupon = DiscountCoupon("HUGE", fixed_amount=Decimal("20.00"))

    totals = compute_totals(cart, policy, coupon=coupon)
    assert totals.subtotal == Decimal("12.00")
    assert totals.discount == Decimal("12.00")
    assert totals.tax == Decimal("0.00")
    assert totals.shipping == Decimal("5.99")
    assert totals.total == totals.shipping


def test_ac4_totals_equation_and_ordering():
    catalog = _make_catalog()
    cart = Cart(catalog)
    cart.add_item("BOOK-1", 1)  # 24.50
    cart.add_item("TECH-1", 1)  # 9.99
    # subtotal = 34.49

    policy = PricingPolicy(
        category_tax_rates={"books": Decimal("5"), "electronics": Decimal("20")},
        flat_shipping=Decimal("5.99"),
        free_shipping_threshold=Decimal("50.00"),
    )
    coupon = DiscountCoupon("COMBO", discount_percent=Decimal("10"), fixed_amount=Decimal("2.00"))

    totals = compute_totals(cart, policy, coupon=coupon)
    expected_total = totals.subtotal - totals.discount + totals.tax + totals.shipping
    assert totals.total == expected_total

    # Check positional order & defaults of Totals
    t = Totals(subtotal=Decimal("10.00"), discount=Decimal("2.00"), tax=Decimal("1.00"), shipping=Decimal("5.00"), total=Decimal("14.00"))
    assert t.subtotal == Decimal("10.00")
    assert t.discount == Decimal("2.00")
    assert t.tax == Decimal("1.00")
    assert t.shipping == Decimal("5.00")
    assert t.total == Decimal("14.00")


def test_ac5_coupon_none_preserves_behavior():
    catalog = _make_catalog()
    cart = Cart(catalog)
    cart.add_item("BOOK-1", 2)  # subtotal = 49.00

    policy = PricingPolicy(default_tax_rate=Decimal("8"), flat_shipping=Decimal("5.99"))
    totals_with_none = compute_totals(cart, policy, coupon=None)
    totals_default = compute_totals(cart, policy)

    assert totals_with_none.discount == Decimal("0.00")
    assert totals_with_none == totals_default
    assert totals_with_none.subtotal == Decimal("49.00")
    assert totals_with_none.shipping == Decimal("5.99")
    assert totals_with_none.tax == Decimal("3.92")
    assert totals_with_none.total == Decimal("58.91")


def test_proportional_tax_per_category():
    catalog = _make_catalog()
    cart = Cart(catalog)
    cart.add_item("BOOK-1", 2)  # 49.00 (books)
    cart.add_item("TECH-1", 1)  # 9.99 (electronics)
    # cart subtotal = 58.99

    policy = PricingPolicy(
        category_tax_rates={"books": Decimal("10"), "electronics": Decimal("20")},
        free_shipping_threshold=Decimal("100.00"),
    )
    # Coupon = 10.00 fixed discount
    coupon = DiscountCoupon("FLAT10", fixed_amount=Decimal("10.00"))
    # factor = 1 - 10.00 / 58.99 = 48.99 / 58.99
    # Line 1 (BOOK-1): line_total=49.00 -> base = 49.00 * (48.99/58.99) = 40.6934... -> tax@10% = 4.07
    # Line 2 (TECH-1): line_total=9.99 -> base = 9.99 * (48.99/58.99) = 8.2965... -> tax@20% = 1.66
    # total tax = 4.07 + 1.66 = 5.73
    totals = compute_totals(cart, policy, coupon=coupon)
    assert totals.subtotal == Decimal("58.99")
    assert totals.discount == Decimal("10.00")
    assert totals.tax == Decimal("5.73")


def test_empty_cart_with_zero_min_subtotal_coupon():
    catalog = _make_catalog()
    cart = Cart(catalog)
    coupon = DiscountCoupon("FREE", discount_percent=Decimal("50"), min_subtotal=Decimal("0"))

    totals = compute_totals(cart, coupon=coupon)
    assert totals.subtotal == Decimal("0.00")
    assert totals.discount == Decimal("0.00")
    assert totals.tax == Decimal("0.00")
    assert totals.shipping == Decimal("0.00")
    assert totals.total == Decimal("0.00")
